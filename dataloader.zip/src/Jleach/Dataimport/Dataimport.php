<?php namespace Jleach\Dataimport;

class Dataimport {

public function hello(){
	return "\"REALLLY\"";
}
}

